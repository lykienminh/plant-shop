
const listServices = [
    {
      id: 1,
      name: "Dụng cụ chăm sóc cây",
      description: "Nec feugiat in fermentum posuere urna. Placerat orci nulla pellentesque dignissim.",
      image: require('../../images/service-icon-02.png'),
    },
    {
      id: 2,
      name: "Hướng dẫn chăm sóc cây",
      description: "Dictumst quisque sit amet risus nullam eget felis eget tortor vitae.",
      image: require('../../images/service-icon-04.png'),
    },
    {
      id: 3,
      name: "Xây dựng không gian xanh",
      description: "Nec feugiat in fermentum posuere urna. Placerat orci nulla pellentesque dignissim.",
      image: require('../../images/service-icon-06.png'),
    },
];

export default listServices;