import React from 'react';
import '../styles/Service.css';

const Service = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '90vh'
      }}
    >
      <h1>Service</h1>
    </div>
  );
};

export default Service;